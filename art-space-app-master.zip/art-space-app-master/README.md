# Art Space App

This Art Space App is related some famous art pictures with their owner names and the year in which they made.

## UI

![Screenshot_20230705_132625 (1)](https://github.com/offfahad/art-space-app/assets/19569802/269e1e11-e807-4d5a-896b-91d71d67dce8)
