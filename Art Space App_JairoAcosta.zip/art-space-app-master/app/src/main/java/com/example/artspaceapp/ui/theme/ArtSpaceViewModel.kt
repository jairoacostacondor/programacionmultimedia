package com.example.artspaceapp.ui.theme

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.example.artspaceapp.ui.ArtSpaceUiState


 class ArtSpaceViewModel : ViewModel() {

    //inicio del ui
    private  val _uiSate = mutableStateOf(ArtSpaceUiState())
    val uiState = _uiSate

    //funcion para cambiar la obra de arte hacia atras
    fun decrement() {
        _uiSate.value = _uiSate.value.copy(
            currentArtIndex = (_uiSate.value.currentArtIndex-1).coerceAtLeast(0)
        )
    }
    //funcion para cambiar la obra de arte hacia delante
    fun increment() {
        _uiSate.value = _uiSate.value.copy(
            currentArtIndex = (_uiSate.value.currentArtIndex+1).coerceAtMost(5)
        )
    }
}