package com.example.artspaceapp.ui

data class ArtSpaceUiState (
    val currentArtIndex : Int = 0
)
